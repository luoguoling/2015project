__author__ = 'Administrator'
LOGMANGER_MYSQL = {
        "host": "211.237.12.103",
        "port": 5849,
        "database": "serverlist",
        "user": "select",
        "password": "abc123?"


        }
