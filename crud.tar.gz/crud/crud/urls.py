from django.conf.urls import patterns, include, url
from django.contrib import admin
#from crudapp.views import hello,myhtml,bb,show,add,query,beginAdd,delByID,showUid
urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'crud.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),
    url(r'^hello/$','crudapp.views.hello'),
    url(r'^myhtml/$','crudapp.views.myhtml'),
    url(r'^cc/$','crudapp.views.bb'),
    url(r'^show/$','crudapp.views.show'),
    url(r'^add/','crudapp.views.add'),
    url(r'^q/$','crudapp.views.query'),
    url(r'^index.html$','crudapp.views.beginAdd'),
    url(r'^delete$','crudapp.views.delByID'),
    url(r'showid$','crudapp.views.showUid'),
    url(r'^admin/', include(admin.site.urls)),
)
