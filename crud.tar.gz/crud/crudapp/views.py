#coding:utf-8
from django.shortcuts import render
from django.shortcuts import render_to_response
from django.http import HttpResponse,HttpResponseRedirect
from django.template.context import RequestContext
from django.views.decorators.csrf import csrf_exempt
import random
from .models import Student
from django.core.context_processors import csrf
# Create your views here.
def hello(request):
    return HttpResponse("first django demo")
def myhtml(request):
    return render_to_response('a.html',locals())
def bb(request):
    return render(request,'bb.html')
def beginAdd(request):
    return render_to_response('add.html')
@csrf_exempt
#"""add data"""
def add(request):
    id = request.POST['id']
    name = request.POST['name']
    age = request.POST['age']
    st = Student()
    if len(id) > 0:
        print ("id 不是null")
        st.id = id
    st.age = age
    st.name = name
    st.save()
    return HttpResponseRedirect("/q/")
"""show all  data """
def query(request):
    b = Student.objects.all()
    return render_to_response('curd.html',{'data':b})
"""show one data """
def showUid(request):
    id = request.GET['id']
    bb = Student.objects.get(id=id)
    return render_to_response('update.html',{'data':bb})
"delete data"
def delByID(request):
    id = request.GET['id']
    bb = Student.objects.get(id=id)
    bb.delete()
    return HttpResponseRedirect('/q/')
datas = [
    {"id":"1","name":"华为"},  
    {"id":"2","name":"三星"},  
    {"id":"4","name":"Apple"},  
    {"id":"5","name":"中国"},  
    {"id":"6","name":"JAVA程序员"},  
    {"id":"7","name":"solr"},  
    {"id":"8","name":"hadoop编程"},  
    {"id":"9","name":"python"},  
    ]
def show(request):
    return render_to_response('data.html',{'datas':datas})

